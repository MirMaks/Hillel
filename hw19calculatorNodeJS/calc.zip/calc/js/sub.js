const sub = (currentNumber, number) => {
	return currentNumber -= number;
}
module.exports = sub;