const div = (currentNumber, number) => {
	return currentNumber /= number;
}
module.exports = div;