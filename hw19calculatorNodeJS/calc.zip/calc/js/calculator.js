const add = require('./add');
const sub = require('./sub');
const mult = require('./mult');
const div = require('./div');

let currentNumber = 10;

module.exports = {
	add: (number) => {
		return currentNumber = add(currentNumber, number);
	},
	sub: (number) => {
		return currentNumber = sub(currentNumber, number);
	},
	mult: (number) => {
		return currentNumber = mult(currentNumber, number);
	},
	div: (number) => {
		return currentNumber = div(currentNumber, number);
	}

}