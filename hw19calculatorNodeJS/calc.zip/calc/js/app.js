// Файл app.js
// const calculator = require('./calculator');	
// console.log(calculator.add(2)) // 12
// console.log(calculator.sub(5)) // 7
// console.log(calculator.mult(4)) // 28
// console.log(calculator.div(2)) // 14

// Задание
// 1) Сделать npm модуль
// 2) set, add, sub, mult, div должны быть отдельными файлами и подключаться в файл calculator

const calculator = require('./calculator');
console.log(calculator.add(2)) // 12
console.log(calculator.sub(5)) // 7
console.log(calculator.mult(4)) // 28
console.log(calculator.div(2)) // 14