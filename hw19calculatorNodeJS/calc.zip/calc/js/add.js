const add = (currentNumber, number) => {
	return currentNumber += number;
}
module.exports = add;
