const mult = (currentNumber, number) => {
	return currentNumber *= number;
}
module.exports = mult;